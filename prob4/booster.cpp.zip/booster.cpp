/*
 * =====================================================================================
 *
 *       Filename:  booster.cpp
 *
 *    Description:  2018 Kakao Code Festival Prob 4 : Is possible to reach another checkpoint?
 *
 *        Version:  1.0
 *        Created:  08/04/18 15:56:42
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Junghyun Kim
 *   Organization:  
 *
 * =====================================================================================
 */

#include <iostream>
#include <queue>
#include <map>
#include <cmath>
using namespace std;

#define WHITE 0
#define GREY 1
#define BLACK 2

int *X, *Y, *C;
int numCheck, numQuery;
queue<int> actives;
map<int, vector<int> > Xmap;
map<int, vector<int> > Ymap;

int minDist(int start, int end) {
    if(abs(X[start] - X[end]) < abs(Y[start] - Y[end])) {
        return abs(X[start] - X[end]);
    } else {
        return abs(Y[start] - Y[end]);
    }
}

bool isPossible(int end, int hp) {
    while(!actives.empty()) {
        int start = actives.front();
        actives.pop();

        for(int x = X[start] - hp; x <= X[start] + hp; x++) {
            for(int i = 0; i < Xmap[x].size(); i++) {
                int id = Xmap[x][i];
                if (id == end) return true;
                if(C[id] == WHITE) {
                    actives.push(id);
                    C[id] = GREY;
                }
            }
        }

        for(int y = Y[start] - hp; y <= Y[start] + hp; y++) {
            for(int i = 0; i < Ymap[y].size(); i++) {
                int id = Ymap[y][i];
                if (id == end) return true;
                if(C[id] == WHITE) {
                    actives.push(id);
                    C[id] = GREY;
                }
            }
        }

        C[start] = BLACK;
    }

    return false;
}

int main() {
    cin >> numCheck >> numQuery;

    X = new int[numCheck+1];
    Y = new int[numCheck+1];
    C = new int[numCheck+1];

    for(int i = 1; i <= numCheck; i++) {
        cin >> X[i] >> Y[i];
        C[i] = WHITE;
        Xmap[X[i]].push_back(i);
        Ymap[Y[i]].push_back(i);
    }

    for(int query = 0; query < numQuery; query++) {
        int start, end, hp;
        cin >> start >> end >> hp;

        queue<int> emptyQueue;
        actives.swap(emptyQueue);
        /*
        while(!actives.empty()) {
            actives.pop();
        }
        */

        for(int i = 1; i <= numCheck; i++) {
            C[i] = WHITE;
        }

        actives.push(start);
        if(isPossible(end, hp)) {
            cout << "YES" << endl;
        } else {
            cout << "NO" << endl;
        }
    }

    delete [] X;
    delete [] Y;
    delete [] C;

    return 0;
}
